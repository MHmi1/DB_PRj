
import React, { use, useState } from "react"


const RegisterBusiness = () => {


    const [addr , setAddr] = useState();
 
    const [addrList, setAddrList] = useState([]);

    const [category , setCategory] = useState();

    const [categoryList, setCategoryList] = useState([]);
    

    
    return (
        <>


        
       
        <link href="https://cdnjs.cloudflare.com/ajax/libs/MaterialDesign-Webfont/5.3.45/css/materialdesignicons.min.css" rel="stylesheet">
        </link>





        <div className="min-w-screen min-h-screen bg-gray-900 felx-col items-center justify-center px-5 py-5">
        <div className="flex items-centers justify-center mt-10">
            <div className="bg-gray-100 text-gray-700 rounded-3xl shadow-xl w-full overflow-hidden" style={{maxWidth:"1000px"}}>
           
           
           <div className="md:flex w-full">
               <div className="hidden md:block w-1/2 bg-orange-700">
               <img src="photo1678386576.jpeg" style={{height:"1200px"}} />
               </div>
               <div className="w-full md:w-1/2 py-10 px-5 md:px-10">
                   <div className="text-center mb-10">
                       <h1 className="font-bold text-3xl text-gray-900">Register Business</h1>
                       <p>Enter your information to register</p>
                   </div>
                   <div>
                       <form>
                       <div className="flex mx-3">
                           <div className="w-1/2 px-3 mb-5">
                               <label className="text-xs font-semibold px-1">Business Name</label>
                               <div className="flex">
                                   <div className="w-10 z-10 pl-1 text-center pointer-events-none flex items-center justify-center"><i className="mdi mdi-account-outline text-gray-400 text-lg"></i></div>
                                   <input type="text" className="w-full -ml-10 pl-10 pr-3 py-2 rounded-lg border-2 border-gray-200 outline-none focus:border-orange-700" placeholder="Enter Business Name"/>
                               </div>
                           </div>
                       </div>
                       <div className="flex mx-3">
                           <div className="w-full px-3 mb-5">
                               <label className="text-xs font-semibold px-1">Business Email</label>
                               <div className="flex">
                                   <div className="w-10 z-10 pl-1 text-center pointer-events-none flex items-center justify-center"><i className="mdi mdi-email-outline text-gray-400 text-lg"></i></div>
                                   <input type="email" className="w-full -ml-10 pl-10 pr-3 py-2 rounded-lg border-2 border-gray-200 outline-none focus:border-orange-700" placeholder=" info@business.com "/>
                               </div>
                           </div>
                       </div>
               


                       <div className="flex mx-3">
                           <div className="w-full px-3 mb-12">
                               <label className="text-xs font-semibold px-1">Business Location</label>
                               <div className="flex-col">
                                  <div className="flex">
                                  <div className="w-10 z-10 pl-1 text-center flex items-center justify-center cursor-pointer">
                                 
                                    
                                 </div>
                                <input value={addr} onChange={(e) => setAddr(e.target.value)} type="text" className="w-full -ml-10 pl-10 pr-3 py-2 rounded-lg border-2 border-gray-200 outline-none focus:border-orange-700"/>
                                <button type="button" className="cursor-pointer" onClick={() => {
                                     console.log("VfvfdvdDD", addr);
                                 
                                     setAddrList([...addrList, addr]);
                                     console.log(addrList);
                                 }}>
                                     +
                                 </button>
                                  </div>
                                   <div>
                                   {
                                    
                                    addrList && addrList.map((value, index) => <h1 key={index}>{value}, </h1>)

                                 
                                   
                                  }
                                   </div>
                               </div>
                           </div>
                       </div>


                       <div className="flex mx-3">
                           <div className="w-full px-3 mb-12">
                               <label className="text-xs font-semibold px-1">Category (like Machine Learning)</label>
                               <div className="flex-col">
                                  <div className="flex">
                                  <div className="w-10 z-10 pl-1 text-center flex items-center justify-center cursor-pointer">
                                 
                                    
                                 </div>
                                <input value={category} onChange={(e) => setCategory(e.target.value)} type="text" className="w-full -ml-10 pl-10 pr-3 py-2 rounded-lg border-2 border-gray-200 outline-none focus:border-orange-700"/>
                                <button type="button" className="cursor-pointer" onClick={() => {
                                     console.log("VfvfdvdDD", category);
                                 
                                     setCategoryList([...categoryList, category]);
                                     console.log(categoryList);
                                 }}>
                                     +
                                 </button>
                                  </div>
                                   <div>
                                   {
                                    
                                    categoryList && categoryList.map((value, index) => <h1 key={index}>{value}, </h1>)

                                 
                                   
                                  }
                                   </div>
                               </div>
                           </div>
                       </div>


                       <div className="flex mx-3">
                           <div className="w-full px-3 mb-12">
                               <label className="text-xs font-semibold px-1">Fund date</label>
                               <div className="flex">
                                   <div className="w-10 z-10 pl-1 text-center pointer-events-none flex items-center justify-center"></div>
                                   <input type="date" className="w-full -ml-10 pl-10 pr-3 py-2 rounded-lg border-2 border-gray-200 outline-none focus:border-orange-700"/>
                               </div>
                           </div>
                       </div>





                       <div className="flex mx-3">
                           <div className="w-full px-3 mb-12">
                               <label className="text-xs font-semibold px-1">Website Address</label>
                               <div className="flex">
                                   <div className="w-10 z-10 pl-1 text-center pointer-events-none flex items-center justify-center"></div>
                                   <input type="text" className="w-full -ml-10 pl-10 pr-3 py-2 rounded-lg border-2 border-gray-200 outline-none focus:border-orange-700"/>
                               </div>
                           </div>
                       </div>

                    


                       


                       <div className="flex -mx-3">
                           <div className="w-full px-3 mb-5">
                               <button className="block w-full max-w-xs mx-auto bg-orange-700 hover:bg-orange-700 focus:bg-orange-700 text-white rounded-lg px-3 py-3 font-semibold">REGISTER Business</button>
                           </div>
                       </div>

                       <div className="mx-2 mb-20">
                      <p>
                        Do you have an account?
                        </p>
                        <button onClick={() => setLogin(true)}>
                            login
                        </button>
                       </div>
                       </form>
                   </div>
               </div>
           </div>
       </div>
            </div></div>

    



        </>
    )
  }
    
  export default RegisterBusiness